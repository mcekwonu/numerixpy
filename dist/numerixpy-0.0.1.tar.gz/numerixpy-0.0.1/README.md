# Numeric Python

This is a numerical differentiation and integration package
to write your content.

## Installation

```pip install numerixpy``` 
