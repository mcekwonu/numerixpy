__all__ = ["Square", "timing"]
